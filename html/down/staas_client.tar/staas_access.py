#!/usr/bin/python 
import commands 
commands.getstatusoutput('sudo systemctl restart nfs-utils')
commands.getstatusoutput('sudo mkdir /media/First')
commands.getstatusoutput('sudo mount 192.168.1.100:/mnt/First /media/First')